import java.util.ArrayList;

public class ContainerItem extends Item 
{
    private ArrayList<Item> items;
    
    public ContainerItem(String name, String type, String description) 
    {
        super(name, type, description);
        items = new ArrayList<>();
    }
    
    public void addItem(Item item) 
    {
        items.add(item);
    }
    
    public boolean hasItem(String itemName) 
    {
        for (Item item : items) 
        {
            if (item.getName().equalsIgnoreCase(itemName)) 
            {
                return true;
            }
        }
        return false;
    }
    
    public Item removeItem(String itemName) 
    {
        for (int i = 0; i < items.size(); i++) 
        {
            if (items.get(i).getName().equalsIgnoreCase(itemName)) 
            {
                return items.remove(i);
            }
        }
        return null;
    }

    public int numItems() {
        return items.size();
    }

    public Item getItem(int index) {
        return items.get(index);
    }
    
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("\n");
        for (Item item : items) 
        {
            sb.append(" + ").append(item.getName()).append("\n");
        }
        return sb.toString().trim();
    }
}
