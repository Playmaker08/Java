import java.util.ArrayList;
import java.util.HashMap;

public class Location 
{
    // Member variables
    private String name;
    private String description;
    private ArrayList<Item> items;
    
    // HashMap: maps direction names (e.g., "north") to adjacent Location objects
    private HashMap<String, Location> connections;
    
    // Constructor:
    public Location(String name, String description) 
    {
        this.name = name;
        this.description = description;
        this.items = new ArrayList<>();
        this.connections = new HashMap<>();
    }
    
    // Getter methods
    public String getName() 
    {
        return name;
    }
    
    public String getDescription() 
    {
        return description;
    }
    
    // Setter methods
    public void setName(String name) 
    {
        this.name = name;
    }
    
    public void setDescription(String description) 
    {
        this.description = description;
    }
    
    // addItem: Adds an Item object to the location.
    public void addItem(Item item) 
    {
        items.add(item);
    }

    // hasItem: Checks if an item with the given name exists in the location.
    public boolean hasItem(String itemName) 
    {
        for (Item item : items) 
        {
            if (item.getName().equalsIgnoreCase(itemName)) 
            {
                return true;
            }
        }
        return false;
    }

    // getItem: Returns the Item object matching the given name (ignoring case).
    public Item getItem(String itemName) 
    {
        for (Item item : items) 
        {
            if (item.getName().equalsIgnoreCase(itemName)) 
            {
                return item;
            }
        }
        return null;
    }
    
    // Overloaded getItem: Returns the Item object at the specified index.
    public Item getItem(int index) 
    {
        if (index >= 0 && index < items.size()) 
        {
            return items.get(index);
        }
        return null;
    }
    
    // numItems: Returns the number of items in the location.
    public int numItems() 
    {
        return items.size();
    }
    
    // removeItem: Removes the item with the given name and returns it.
    public Item removeItem(String itemName) 
    {
        for (int i = 0; i < items.size(); i++) 
        {
            if (items.get(i).getName().equalsIgnoreCase(itemName)) 
            {
                return items.remove(i);
            }
        }
        return null;
    }
    
    // connect: Adds a connection between this location and another location in the given direction.
    public void connect(String direction, Location location) 
    {
        // Convert the direction to lowercase to ensure consistency.
        connections.put(direction.toLowerCase(), location);
    }
    
    // canMove: Returns true if there is an adjacent location in the specified direction.
    public boolean canMove(String direction) 
    {
        return connections.containsKey(direction.toLowerCase());
    }
    
    // getLocation: Returns the Location object associated with the given direction, or null if none exists.
    public Location getLocation(String direction) 
    {
        return connections.get(direction.toLowerCase());
    }
}
