public class Item 
{
    
    // Member variables
    private String name;
    private String type;
    private String description;
    
    // Constructor
    public Item(String name, String type, String description) 
    {
        this.name = name;
        this.type = type;
        this.description = description;
    }
    
    // Getter methods
    public String getName() 
    {
        return name;
    }
    
    public String getType() 
    {
        return type;
    }
    
    public String getDescription() 
    {
        return description;
    }
    
    // Setter methods
    public void setName(String name) 
    {
        this.name = name;
    }
    
    public void setType(String type) 
    {
        this.type = type;
    }
    
    public void setDescription(String description) 
    {
        this.description = description;
    }
    
    // The toString method formally returning item information
    public String toString() {
        return name + " [ " + type + " ] : " + description;
    }
}
