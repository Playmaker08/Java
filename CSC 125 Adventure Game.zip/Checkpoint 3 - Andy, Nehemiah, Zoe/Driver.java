import java.util.Scanner;

public class Driver 
{
    static Location currLocation;
    static ContainerItem myInventory;
    
    public static void main(String[] args) 
    {
        // Display welcome message.
        System.out.println("Welcome to Monon Bell Mystery!\n");
        System.out.println("You step into the lobby of Lilly, expecting to see the gleaming Monon Bell perched on its pedestal—but the pressure plate lies bare, and the shrill whine of a triggered alarm echoes down the hallway. You must explore the campus, solve riddles, and interview quirky NPCs (professors, janitors, students, etc.) to recover it before sunrise.");
        // Build the game world and set the starting location.
        createWorld();
        // Initialize the player's inventory ("Backpack").
        myInventory = new ContainerItem("Backpack", "Container", "A sturdy backpack to carry your items.");
        
        Scanner scanner = new Scanner(System.in);
        
        while (true) 
        {
            System.out.print("Enter command: ");
            String input = scanner.nextLine().trim();
            String[] words = input.split(" ");
            if (words.length == 0 || words[0].equals("")) continue;
            String command = words[0].toLowerCase();
            
            switch (command) 
            {
                case "quit":
                    System.out.println("Game Over");
                    scanner.close();
                    System.exit(0);
                    break;
                
                case "look":
                    System.out.println("\n" + currLocation.getName() + " - " + currLocation.getDescription());
                    if (currLocation.numItems() > 0) 
                    {
                        System.out.println("Items at this location:");
                        for (int i = 0; i < currLocation.numItems(); i++) 
                        {
                            System.out.println(" + " + currLocation.getItem(i).getName());
                        }
                    } 
                    else 
                    {
                        System.out.println("There are no items here.");
                    }
                    System.out.println();
                    break;

                case "inventory":
                    if (myInventory.numItems() > 0) 
                    {
                        System.out.println("Your inventory:");
                        for (int i = 0; i < myInventory.numItems(); i++) 
                        {
                            System.out.println(" + " + myInventory.getItem(i).getName());
                        }
                    } 
                    else 
                    {
                        System.out.println("Your inventory is empty.");
                    }
                    System.out.println();
                    break;

                case "examine":
                    if (words.length < 2) 
                    {
                        System.out.println("Please specify an item or container to examine.\n");
                    } 
                    else 
                    {
                        String name = words[1];
                        Item itemToExamine = currLocation.getItem(name);
                        if (itemToExamine == null && myInventory.hasItem(name)) {
                            itemToExamine = myInventory.removeItem(name);
                            myInventory.addItem(itemToExamine);
                        }
                        if (itemToExamine != null) 
                        {
                            System.out.println(itemToExamine.toString());
                            if (itemToExamine instanceof ContainerItem) {
                                ContainerItem container = (ContainerItem) itemToExamine;
                                if (container.numItems() > 0) {
                                    System.out.println("Contains:");
                                    for (int i = 0; i < container.numItems(); i++) {
                                        System.out.println(" - " + container.getItem(i).getName());
                                    }
                                } else {
                                    System.out.println("(Empty)");
                                }
                            }
                            System.out.println();
                        } 
                        else 
                        {
                            System.out.println("Item not found.\n");
                        }
                    }
                    break;

                case "go":
                    if (words.length < 2) 
                    {
                        System.out.println("Please specify a direction to go (north, south, east, or west).\n");
                    } 
                    else 
                    {
                        String direction = words[1].toLowerCase();
                        if (currLocation.canMove(direction)) 
                        {
                            currLocation = currLocation.getLocation(direction);
                            System.out.println("You move " + direction + " to the " + currLocation.getName() + ".\n");
                        } 
                        else 
                        {
                            System.out.println("You can't go that way!\n");
                        }
                    }
                    break;

                case "take":
                    if (words.length == 4 && words[2].equalsIgnoreCase("from")) {
                        String itemName = words[1];
                        String containerName = words[3];
                        Item contItem = currLocation.getItem(containerName);
                        if (contItem instanceof ContainerItem) {
                            ContainerItem container = (ContainerItem) contItem;
                            if (container.hasItem(itemName)) {
                                Item taken = container.removeItem(itemName);
                                myInventory.addItem(taken);
                                System.out.println("You take the " + taken.getName() + " from the " + container.getName() + ".\n");
                            } else {
                                System.out.println("That container does not contain a " + itemName + ".\n");
                            }
                        } else {
                            System.out.println("Cannot find that container here.\n");
                        }
                    } 
                    else if (words.length == 2) {
                        String itemName = words[1].toLowerCase();
                        if (currLocation.hasItem(itemName)) 
                        {
                            Item takenItem = currLocation.removeItem(itemName);
                            myInventory.addItem(takenItem);
                            System.out.println("You take the " + takenItem.getName() + ".\n");
                        } 
                        else 
                        {
                            System.out.println("Cannot find that item here.\n");
                        }
                    } 
                    else 
                    {
                        System.out.println("Invalid take command. Use: take <item> or take <item> from <container>.\n");
                    }
                    break;

                case "put":
                    if (words.length == 4 && words[2].equalsIgnoreCase("in")) {
                        String itemName = words[1];
                        String containerName = words[3];
                        if (myInventory.hasItem(itemName)) {
                            Item toPut = myInventory.removeItem(itemName);
                            Item contItem = currLocation.getItem(containerName);
                            if (contItem instanceof ContainerItem) {
                                ContainerItem container = (ContainerItem) contItem;
                                container.addItem(toPut);
                                System.out.println("You put the " + toPut.getName() + " in the " + container.getName() + ".\n");
                            } else {
                                myInventory.addItem(toPut);
                                System.out.println("Cannot find that container here.\n");
                            }
                        } else {
                            System.out.println("You don't have a " + itemName + " in your inventory.\n");
                        }
                    } else {
                        System.out.println("Invalid put command. Use: put <item> in <container>.\n");
                    }
                    break;

                case "drop":
                    if (words.length < 2) 
                    {
                        System.out.println("Please specify an item to drop.\n");
                    } 
                    else 
                    {
                        String itemName = words[1].toLowerCase();
                        if (myInventory.hasItem(itemName)) 
                        {
                            Item droppedItem = myInventory.removeItem(itemName);
                            currLocation.addItem(droppedItem);
                            System.out.println("You drop the " + droppedItem.getName() + ".\n");
                        } 
                        else 
                        {
                            System.out.println("Cannot find that item in your inventory.\n");
                        }
                    }
                    break;

                case "help":
                    printHelp();
                    break;

                default:
                    System.out.println("Unable to do that.\n");
                    break;
            }
        }
    }
    
    public static void createWorld() {
        Location lilly = new Location("Lilly Center",
            "The scent of sweat clings to the air. The lobby feels empty; a hole of nothingness exists where the bell normally sits.");
        Location eastCollege = new Location("East College",
            "An old, echoing hall lined with portraits. The air smells like dust and secrets.");
        Location roy = new Location("Roy O. West Library",
            "Rows of silent books stretch into the dark. A computer screen flickers on with no one nearby.");
        Location naturePark = new Location("Nature Park",
            "The woods close in around you. Fog curls low along the trail.");

        // Connect
        lilly.connect("north", roy);       roy.connect("south", lilly);
        roy.connect("east", eastCollege);  eastCollege.connect("west", roy);
        roy.connect("west", naturePark);   naturePark.connect("east", roy);

        // Add regular items
        lilly.addItem(new Item("Dumbells","Tool","A dumbbell from the weight rack."));
        lilly.addItem(new Item("Basketball","Item","Sitting on the gym floor."));
        eastCollege.addItem(new Item("Painting","Decoration","A faculty portrait."));
        roy.addItem(new Item("Books","Item","Dusty tomes."));
        naturePark.addItem(new Item("Wallet","Item","Contains a Wabash ID."));

        // Add container items
        ContainerItem chest = new ContainerItem("Chest","Container",
            "An old wooden chest with iron bands.");
        chest.addItem(new Item("Key","Tool","A small brass key."));
        lilly.addItem(chest);

        ContainerItem desk = new ContainerItem("Desk","Container",
            "An antique desk with a locked drawer.");
        desk.addItem(new Item("Scroll","Document","A dusty parchment scroll."));
        eastCollege.addItem(desk);

        ContainerItem trophyCase = new ContainerItem("TrophyCase","Container",
            "A glass trophy case filled with awards.");
        trophyCase.addItem(new Item("Sword","Weapon","A steel sword with runes."));
        roy.addItem(trophyCase);

        currLocation = lilly;
    }

    public static void printHelp() {
        System.out.println("\nSupported commands:");
        System.out.println("  look                   - Show your current location and items here");
        System.out.println("  go <direction>         - Move north, south, east, or west");
        System.out.println("  examine <item|cont>    - Describe an item or container");
        System.out.println("  take <item>            - Pick up a loose item here");
        System.out.println("  take <item> from <cont>- Take an item out of a container");
        System.out.println("  put <item> in <cont>   - Put an inventory item into a container");
        System.out.println("  drop <item>            - Drop an item from your inventory");
        System.out.println("  inventory              - List items in your backpack");
        System.out.println("  help                   - List all commands");
        System.out.println("  quit                   - Exit the game\n");
    }
}
